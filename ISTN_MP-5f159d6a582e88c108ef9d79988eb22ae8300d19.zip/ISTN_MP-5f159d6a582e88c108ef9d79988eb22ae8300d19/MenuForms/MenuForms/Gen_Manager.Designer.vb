﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GenManager
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.PurchaseOrder = New System.Windows.Forms.TabPage()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Product_Code = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cost_Price = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Purchase_Quantity = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Subtotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Total_Cost = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.TextBox58 = New System.Windows.Forms.TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Employee = New System.Windows.Forms.TabPage()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.TextBox39 = New System.Windows.Forms.TextBox()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox43 = New System.Windows.Forms.TextBox()
        Me.TextBox44 = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Product = New System.Windows.Forms.TabControl()
        Me.Products = New System.Windows.Forms.TabPage()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btrnDisableProduct = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.cbSearchParam = New System.Windows.Forms.ComboBox()
        Me.DataGridView5 = New System.Windows.Forms.DataGridView()
        Me.ProductCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductDescript = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SellingPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OnHand = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Vat = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.Active = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.PONum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PoDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReturnId = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastReturnDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tbcSupplier = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Customer = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.btnAddNewProduct = New System.Windows.Forms.Button()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Payment = New System.Windows.Forms.TabPage()
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Me.ComboBox7 = New System.Windows.Forms.ComboBox()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Supplier = New System.Windows.Forms.TabPage()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.PurchaseOrder.SuspendLayout
        CType(Me.DataGridView1,System.ComponentModel.ISupportInitialize).BeginInit
        Me.Employee.SuspendLayout
        Me.Product.SuspendLayout
        Me.Products.SuspendLayout
        Me.Panel3.SuspendLayout
        CType(Me.DataGridView5,System.ComponentModel.ISupportInitialize).BeginInit
        Me.Customer.SuspendLayout
        Me.Panel1.SuspendLayout
        CType(Me.DataGridView2,System.ComponentModel.ISupportInitialize).BeginInit
        Me.Payment.SuspendLayout
        CType(Me.DataGridView4,System.ComponentModel.ISupportInitialize).BeginInit
        Me.Supplier.SuspendLayout
        Me.Panel2.SuspendLayout
        CType(Me.DataGridView3,System.ComponentModel.ISupportInitialize).BeginInit
        Me.SuspendLayout
        '
        'PurchaseOrder
        '
        Me.PurchaseOrder.Controls.Add(Me.DataGridView1)
        Me.PurchaseOrder.Controls.Add(Me.ComboBox2)
        Me.PurchaseOrder.Controls.Add(Me.ComboBox1)
        Me.PurchaseOrder.Controls.Add(Me.DateTimePicker1)
        Me.PurchaseOrder.Controls.Add(Me.TextBox58)
        Me.PurchaseOrder.Controls.Add(Me.Label53)
        Me.PurchaseOrder.Controls.Add(Me.Label54)
        Me.PurchaseOrder.Controls.Add(Me.Label57)
        Me.PurchaseOrder.Controls.Add(Me.Label58)
        Me.PurchaseOrder.Controls.Add(Me.Button19)
        Me.PurchaseOrder.Location = New System.Drawing.Point(4, 22)
        Me.PurchaseOrder.Name = "PurchaseOrder"
        Me.PurchaseOrder.Padding = New System.Windows.Forms.Padding(3)
        Me.PurchaseOrder.Size = New System.Drawing.Size(1240, 622)
        Me.PurchaseOrder.TabIndex = 7
        Me.PurchaseOrder.Text = "Purchase Order"
        Me.PurchaseOrder.UseVisualStyleBackColor = true
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Product_Code, Me.Cost_Price, Me.Purchase_Quantity, Me.Subtotal, Me.Total_Cost})
        Me.DataGridView1.Location = New System.Drawing.Point(0, 144)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(543, 645)
        Me.DataGridView1.TabIndex = 60
        '
        'Product_Code
        '
        Me.Product_Code.HeaderText = "Product Code"
        Me.Product_Code.Name = "Product_Code"
        '
        'Cost_Price
        '
        Me.Cost_Price.HeaderText = "Cost Price"
        Me.Cost_Price.Name = "Cost_Price"
        '
        'Purchase_Quantity
        '
        Me.Purchase_Quantity.HeaderText = "Purchase Quantity"
        Me.Purchase_Quantity.Name = "Purchase_Quantity"
        '
        'Subtotal
        '
        Me.Subtotal.HeaderText = "Subtotal"
        Me.Subtotal.Name = "Subtotal"
        '
        'Total_Cost
        '
        Me.Total_Cost.HeaderText = "Total Cost"
        Me.Total_Cost.Name = "Total_Cost"
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = true
        Me.ComboBox2.Location = New System.Drawing.Point(182, 99)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(200, 21)
        Me.ComboBox2.TabIndex = 59
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = true
        Me.ComboBox1.Location = New System.Drawing.Point(182, 72)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(200, 21)
        Me.ComboBox1.TabIndex = 58
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(182, 46)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 57
        '
        'TextBox58
        '
        Me.TextBox58.Location = New System.Drawing.Point(182, 20)
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.Size = New System.Drawing.Size(200, 20)
        Me.TextBox58.TabIndex = 49
        '
        'Label53
        '
        Me.Label53.AutoSize = true
        Me.Label53.Location = New System.Drawing.Point(42, 72)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(59, 13)
        Me.Label53.TabIndex = 48
        Me.Label53.Text = "Supplier ID"
        '
        'Label54
        '
        Me.Label54.AutoSize = true
        Me.Label54.Location = New System.Drawing.Point(42, 98)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(67, 13)
        Me.Label54.TabIndex = 47
        Me.Label54.Text = "Employee ID"
        '
        'Label57
        '
        Me.Label57.AutoSize = true
        Me.Label57.Location = New System.Drawing.Point(42, 46)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(107, 13)
        Me.Label57.TabIndex = 44
        Me.Label57.Text = "Purchase Order Date"
        '
        'Label58
        '
        Me.Label58.AutoSize = true
        Me.Label58.Location = New System.Drawing.Point(42, 23)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(98, 13)
        Me.Label58.TabIndex = 43
        Me.Label58.Text = "Purchase Order No"
        '
        'Button19
        '
        Me.Button19.Font = New System.Drawing.Font("Microsoft Sans Serif", 18!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Button19.Location = New System.Drawing.Point(405, 20)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(138, 118)
        Me.Button19.TabIndex = 40
        Me.Button19.Text = "Add New  Purchase Order"
        Me.Button19.UseVisualStyleBackColor = true
        '
        'Employee
        '
        Me.Employee.Controls.Add(Me.Button11)
        Me.Employee.Controls.Add(Me.Button12)
        Me.Employee.Controls.Add(Me.Button13)
        Me.Employee.Controls.Add(Me.TextBox38)
        Me.Employee.Controls.Add(Me.TextBox39)
        Me.Employee.Controls.Add(Me.TextBox40)
        Me.Employee.Controls.Add(Me.TextBox41)
        Me.Employee.Controls.Add(Me.TextBox42)
        Me.Employee.Controls.Add(Me.TextBox43)
        Me.Employee.Controls.Add(Me.TextBox44)
        Me.Employee.Controls.Add(Me.Label38)
        Me.Employee.Controls.Add(Me.Label39)
        Me.Employee.Controls.Add(Me.Label40)
        Me.Employee.Controls.Add(Me.Label41)
        Me.Employee.Controls.Add(Me.Label42)
        Me.Employee.Controls.Add(Me.Label43)
        Me.Employee.Controls.Add(Me.Label44)
        Me.Employee.Location = New System.Drawing.Point(4, 22)
        Me.Employee.Name = "Employee"
        Me.Employee.Padding = New System.Windows.Forms.Padding(3)
        Me.Employee.Size = New System.Drawing.Size(1240, 622)
        Me.Employee.TabIndex = 3
        Me.Employee.Text = "Employee"
        Me.Employee.UseVisualStyleBackColor = true
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(471, 195)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(78, 50)
        Me.Button11.TabIndex = 50
        Me.Button11.Text = "Search"
        Me.Button11.UseVisualStyleBackColor = true
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(390, 195)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(78, 50)
        Me.Button12.TabIndex = 49
        Me.Button12.Text = "Delete Employee"
        Me.Button12.UseVisualStyleBackColor = true
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(308, 195)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(78, 50)
        Me.Button13.TabIndex = 48
        Me.Button13.Text = "Add Employee"
        Me.Button13.UseVisualStyleBackColor = true
        '
        'TextBox38
        '
        Me.TextBox38.Location = New System.Drawing.Point(128, 211)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(100, 20)
        Me.TextBox38.TabIndex = 47
        '
        'TextBox39
        '
        Me.TextBox39.Location = New System.Drawing.Point(128, 178)
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Size = New System.Drawing.Size(100, 20)
        Me.TextBox39.TabIndex = 45
        '
        'TextBox40
        '
        Me.TextBox40.Location = New System.Drawing.Point(128, 143)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(100, 20)
        Me.TextBox40.TabIndex = 44
        '
        'TextBox41
        '
        Me.TextBox41.Location = New System.Drawing.Point(128, 113)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(100, 20)
        Me.TextBox41.TabIndex = 43
        '
        'TextBox42
        '
        Me.TextBox42.Location = New System.Drawing.Point(128, 80)
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(100, 20)
        Me.TextBox42.TabIndex = 42
        '
        'TextBox43
        '
        Me.TextBox43.Location = New System.Drawing.Point(128, 54)
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Size = New System.Drawing.Size(100, 20)
        Me.TextBox43.TabIndex = 41
        '
        'TextBox44
        '
        Me.TextBox44.Location = New System.Drawing.Point(128, 21)
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.Size = New System.Drawing.Size(100, 20)
        Me.TextBox44.TabIndex = 40
        '
        'Label38
        '
        Me.Label38.AutoSize = true
        Me.Label38.Location = New System.Drawing.Point(40, 211)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(53, 13)
        Me.Label38.TabIndex = 46
        Me.Label38.Text = "Password"
        '
        'Label39
        '
        Me.Label39.AutoSize = true
        Me.Label39.Location = New System.Drawing.Point(40, 24)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(67, 13)
        Me.Label39.TabIndex = 35
        Me.Label39.Text = "Employee ID"
        '
        'Label40
        '
        Me.Label40.AutoSize = true
        Me.Label40.Location = New System.Drawing.Point(40, 185)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(84, 13)
        Me.Label40.TabIndex = 39
        Me.Label40.Text = "Contact Number"
        '
        'Label41
        '
        Me.Label41.AutoSize = true
        Me.Label41.Location = New System.Drawing.Point(40, 150)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(56, 13)
        Me.Label41.TabIndex = 38
        Me.Label41.Text = "Emp Email"
        '
        'Label42
        '
        Me.Label42.AutoSize = true
        Me.Label42.Location = New System.Drawing.Point(40, 120)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(55, 13)
        Me.Label42.TabIndex = 37
        Me.Label42.Text = "Emp Type"
        '
        'Label43
        '
        Me.Label43.AutoSize = true
        Me.Label43.Location = New System.Drawing.Point(40, 87)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(65, 13)
        Me.Label43.TabIndex = 36
        Me.Label43.Text = "Emp LName"
        '
        'Label44
        '
        Me.Label44.AutoSize = true
        Me.Label44.Location = New System.Drawing.Point(40, 54)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(65, 13)
        Me.Label44.TabIndex = 34
        Me.Label44.Text = "Emp FName"
        '
        'Product
        '
        Me.Product.Controls.Add(Me.Employee)
        Me.Product.Controls.Add(Me.Products)
        Me.Product.Controls.Add(Me.Customer)
        Me.Product.Controls.Add(Me.PurchaseOrder)
        Me.Product.Controls.Add(Me.Payment)
        Me.Product.Controls.Add(Me.Supplier)
        Me.Product.Location = New System.Drawing.Point(-1, 1)
        Me.Product.Name = "Product"
        Me.Product.SelectedIndex = 0
        Me.Product.Size = New System.Drawing.Size(1248, 648)
        Me.Product.TabIndex = 1
        '
        'Products
        '
        Me.Products.Controls.Add(Me.Panel3)
        Me.Products.Controls.Add(Me.cbSearchParam)
        Me.Products.Controls.Add(Me.DataGridView5)
        Me.Products.Controls.Add(Me.TextBox21)
        Me.Products.Controls.Add(Me.Button21)
        Me.Products.Location = New System.Drawing.Point(4, 22)
        Me.Products.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Products.Name = "Products"
        Me.Products.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Products.Size = New System.Drawing.Size(1240, 622)
        Me.Products.TabIndex = 15
        Me.Products.Text = "Products"
        Me.Products.UseVisualStyleBackColor = true
        '
        'Panel3
        '
        Me.Panel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Panel3.Controls.Add(Me.btrnDisableProduct)
        Me.Panel3.Controls.Add(Me.Button2)
        Me.Panel3.Controls.Add(Me.Button18)
        Me.Panel3.Controls.Add(Me.Button20)
        Me.Panel3.Controls.Add(Me.btnUpdate)
        Me.Panel3.Location = New System.Drawing.Point(205, 30)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(841, 126)
        Me.Panel3.TabIndex = 27
        '
        'btrnDisableProduct
        '
        Me.btrnDisableProduct.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
            Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.btrnDisableProduct.Image = Global.MenuForms.My.Resources.Resources.network_error_icon
        Me.btrnDisableProduct.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btrnDisableProduct.Location = New System.Drawing.Point(717, 4)
        Me.btrnDisableProduct.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btrnDisableProduct.Name = "btrnDisableProduct"
        Me.btrnDisableProduct.Size = New System.Drawing.Size(121, 118)
        Me.btrnDisableProduct.TabIndex = 31
        Me.btrnDisableProduct.Text = "Deactivate Product"
        Me.btrnDisableProduct.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btrnDisableProduct.UseVisualStyleBackColor = true
        '
        'Button2
        '
        Me.Button2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
            Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.Button2.Image = Global.MenuForms.My.Resources.Resources.bin_red_full_icon
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button2.Location = New System.Drawing.Point(536, 4)
        Me.Button2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(121, 118)
        Me.Button2.TabIndex = 30
        Me.Button2.Text = "Remove"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button2.UseVisualStyleBackColor = true
        '
        'Button18
        '
        Me.Button18.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
            Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.Button18.Image = Global.MenuForms.My.Resources.Resources.Save_icon
        Me.Button18.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button18.Location = New System.Drawing.Point(350, 4)
        Me.Button18.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(121, 118)
        Me.Button18.TabIndex = 29
        Me.Button18.Text = "Save"
        Me.Button18.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button18.UseVisualStyleBackColor = true
        '
        'Button20
        '
        Me.Button20.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
            Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.Button20.Image = Global.MenuForms.My.Resources.Resources.add_icon
        Me.Button20.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button20.Location = New System.Drawing.Point(5, 4)
        Me.Button20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(121, 118)
        Me.Button20.TabIndex = 27
        Me.Button20.Text = "Add New Product"
        Me.Button20.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button20.UseVisualStyleBackColor = true
        '
        'btnUpdate
        '
        Me.btnUpdate.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
            Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.btnUpdate.Image = Global.MenuForms.My.Resources.Resources.Pencil_icon
        Me.btnUpdate.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnUpdate.Location = New System.Drawing.Point(175, 4)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(121, 118)
        Me.btnUpdate.TabIndex = 28
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnUpdate.UseCompatibleTextRendering = true
        Me.btnUpdate.UseVisualStyleBackColor = true
        '
        'cbSearchParam
        '
        Me.cbSearchParam.FormattingEnabled = true
        Me.cbSearchParam.Items.AddRange(New Object() {"By Product Code", "By Name"})
        Me.cbSearchParam.Location = New System.Drawing.Point(924, 176)
        Me.cbSearchParam.Name = "cbSearchParam"
        Me.cbSearchParam.Size = New System.Drawing.Size(151, 21)
        Me.cbSearchParam.TabIndex = 22
        '
        'DataGridView5
        '
        Me.DataGridView5.AllowUserToOrderColumns = true
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView5.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView5.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ProductCode, Me.ProductDescript, Me.SellingPrice, Me.OnHand, Me.Vat, Me.Active, Me.PONum, Me.PoDate, Me.ReturnId, Me.LastReturnDate, Me.tbcSupplier})
        Me.DataGridView5.Location = New System.Drawing.Point(16, 220)
        Me.DataGridView5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.DataGridView5.Name = "DataGridView5"
        Me.DataGridView5.Size = New System.Drawing.Size(1211, 390)
        Me.DataGridView5.TabIndex = 16
        '
        'ProductCode
        '
        Me.ProductCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.ProductCode.DividerWidth = 1
        Me.ProductCode.FillWeight = 80!
        Me.ProductCode.HeaderText = "Product Code"
        Me.ProductCode.MinimumWidth = 40
        Me.ProductCode.Name = "ProductCode"
        Me.ProductCode.ReadOnly = true
        '
        'ProductDescript
        '
        Me.ProductDescript.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.ProductDescript.FillWeight = 200!
        Me.ProductDescript.HeaderText = "Product Name"
        Me.ProductDescript.MinimumWidth = 80
        Me.ProductDescript.Name = "ProductDescript"
        '
        'SellingPrice
        '
        Me.SellingPrice.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.SellingPrice.FillWeight = 88.55048!
        Me.SellingPrice.HeaderText = "Selling Price"
        Me.SellingPrice.Name = "SellingPrice"
        '
        'OnHand
        '
        Me.OnHand.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.OnHand.FillWeight = 88.55048!
        Me.OnHand.HeaderText = "On Hand"
        Me.OnHand.Name = "OnHand"
        '
        'Vat
        '
        Me.Vat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Vat.FillWeight = 50!
        Me.Vat.HeaderText = "Vat"
        Me.Vat.MinimumWidth = 25
        Me.Vat.Name = "Vat"
        '
        'Active
        '
        Me.Active.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Active.FillWeight = 50!
        Me.Active.HeaderText = "Active"
        Me.Active.MinimumWidth = 25
        Me.Active.Name = "Active"
        '
        'PONum
        '
        Me.PONum.HeaderText = "PO Number"
        Me.PONum.Name = "PONum"
        '
        'PoDate
        '
        Me.PoDate.HeaderText = "Last PO Date"
        Me.PoDate.Name = "PoDate"
        '
        'ReturnId
        '
        Me.ReturnId.HeaderText = "Return ID"
        Me.ReturnId.Name = "ReturnId"
        '
        'LastReturnDate
        '
        Me.LastReturnDate.HeaderText = "Last Return Date"
        Me.LastReturnDate.Name = "LastReturnDate"
        '
        'tbcSupplier
        '
        Me.tbcSupplier.HeaderText = "Supplier"
        Me.tbcSupplier.Name = "tbcSupplier"
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(330, 176)
        Me.TextBox21.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(560, 20)
        Me.TextBox21.TabIndex = 15
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(180, 172)
        Me.Button21.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(125, 30)
        Me.Button21.TabIndex = 14
        Me.Button21.Text = "Search Product"
        Me.Button21.UseVisualStyleBackColor = true
        '
        'Customer
        '
        Me.Customer.Controls.Add(Me.Panel1)
        Me.Customer.Controls.Add(Me.ComboBox3)
        Me.Customer.Controls.Add(Me.TextBox3)
        Me.Customer.Controls.Add(Me.DataGridView2)
        Me.Customer.Controls.Add(Me.Button1)
        Me.Customer.Location = New System.Drawing.Point(4, 22)
        Me.Customer.Name = "Customer"
        Me.Customer.Padding = New System.Windows.Forms.Padding(3)
        Me.Customer.Size = New System.Drawing.Size(1240, 622)
        Me.Customer.TabIndex = 12
        Me.Customer.Text = "Customer"
        Me.Customer.UseVisualStyleBackColor = true
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnRemove)
        Me.Panel1.Controls.Add(Me.btnSave)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.btnAddNewProduct)
        Me.Panel1.Location = New System.Drawing.Point(633, 6)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(171, 415)
        Me.Panel1.TabIndex = 31
        '
        'btnRemove
        '
        Me.btnRemove.Image = Global.MenuForms.My.Resources.Resources.bin_red_full_icon
        Me.btnRemove.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnRemove.Location = New System.Drawing.Point(22, 306)
        Me.btnRemove.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(121, 88)
        Me.btnRemove.TabIndex = 31
        Me.btnRemove.Text = "Remove"
        Me.btnRemove.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnRemove.UseVisualStyleBackColor = true
        '
        'btnSave
        '
        Me.btnSave.Image = Global.MenuForms.My.Resources.Resources.Save_icon
        Me.btnSave.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnSave.Location = New System.Drawing.Point(22, 207)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(121, 91)
        Me.btnSave.TabIndex = 30
        Me.btnSave.Text = "Save"
        Me.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnSave.UseVisualStyleBackColor = true
        '
        'Button4
        '
        Me.Button4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Button4.Image = Global.MenuForms.My.Resources.Resources.Pencil_icon
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button4.Location = New System.Drawing.Point(22, 112)
        Me.Button4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(121, 87)
        Me.Button4.TabIndex = 29
        Me.Button4.Text = "Update"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button4.UseCompatibleTextRendering = true
        Me.Button4.UseVisualStyleBackColor = true
        '
        'btnAddNewProduct
        '
        Me.btnAddNewProduct.Image = Global.MenuForms.My.Resources.Resources.add_icon
        Me.btnAddNewProduct.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnAddNewProduct.Location = New System.Drawing.Point(22, 15)
        Me.btnAddNewProduct.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnAddNewProduct.Name = "btnAddNewProduct"
        Me.btnAddNewProduct.Size = New System.Drawing.Size(121, 89)
        Me.btnAddNewProduct.TabIndex = 28
        Me.btnAddNewProduct.Text = "Add New Customer"
        Me.btnAddNewProduct.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnAddNewProduct.UseVisualStyleBackColor = true
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = true
        Me.ComboBox3.Location = New System.Drawing.Point(358, 20)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox3.TabIndex = 12
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(171, 21)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(151, 20)
        Me.TextBox3.TabIndex = 11
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column7, Me.Column5, Me.Column6, Me.Column8})
        Me.DataGridView2.Location = New System.Drawing.Point(16, 66)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(573, 296)
        Me.DataGridView2.TabIndex = 10
        '
        'Column1
        '
        Me.Column1.HeaderText = "Customer ID"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "First Name"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.HeaderText = "Last Name"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.HeaderText = "Customer Type"
        Me.Column4.Name = "Column4"
        '
        'Column7
        '
        Me.Column7.HeaderText = "Business Name"
        Me.Column7.Name = "Column7"
        '
        'Column5
        '
        Me.Column5.HeaderText = "Customer Email"
        Me.Column5.Name = "Column5"
        '
        'Column6
        '
        Me.Column6.HeaderText = "Contact Number"
        Me.Column6.Name = "Column6"
        '
        'Column8
        '
        Me.Column8.HeaderText = "Address"
        Me.Column8.Name = "Column8"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(16, 16)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(104, 25)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Search Customer"
        Me.Button1.UseVisualStyleBackColor = true
        '
        'Payment
        '
        Me.Payment.Controls.Add(Me.ComboBox6)
        Me.Payment.Controls.Add(Me.ComboBox7)
        Me.Payment.Controls.Add(Me.DataGridView4)
        Me.Payment.Controls.Add(Me.TextBox4)
        Me.Payment.Controls.Add(Me.Button10)
        Me.Payment.Controls.Add(Me.Button17)
        Me.Payment.Location = New System.Drawing.Point(4, 22)
        Me.Payment.Name = "Payment"
        Me.Payment.Padding = New System.Windows.Forms.Padding(3)
        Me.Payment.Size = New System.Drawing.Size(1240, 622)
        Me.Payment.TabIndex = 14
        Me.Payment.Text = "Payment"
        Me.Payment.UseVisualStyleBackColor = true
        '
        'ComboBox6
        '
        Me.ComboBox6.FormattingEnabled = true
        Me.ComboBox6.Location = New System.Drawing.Point(175, 87)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox6.TabIndex = 33
        '
        'ComboBox7
        '
        Me.ComboBox7.FormattingEnabled = true
        Me.ComboBox7.Location = New System.Drawing.Point(386, 22)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox7.TabIndex = 32
        '
        'DataGridView4
        '
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column9, Me.Column10, Me.Column11, Me.Column12, Me.Column13, Me.Column14})
        Me.DataGridView4.Location = New System.Drawing.Point(6, 136)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.Size = New System.Drawing.Size(639, 255)
        Me.DataGridView4.TabIndex = 3
        '
        'Column9
        '
        Me.Column9.HeaderText = "Customer ID"
        Me.Column9.Name = "Column9"
        '
        'Column10
        '
        Me.Column10.HeaderText = "Customer Payment ID"
        Me.Column10.Name = "Column10"
        '
        'Column11
        '
        Me.Column11.HeaderText = "Sales Order ID"
        Me.Column11.Name = "Column11"
        '
        'Column12
        '
        Me.Column12.HeaderText = "Payment Type"
        Me.Column12.Name = "Column12"
        '
        'Column13
        '
        Me.Column13.HeaderText = "Payment Total"
        Me.Column13.Name = "Column13"
        '
        'Column14
        '
        Me.Column14.HeaderText = "Payment Date"
        Me.Column14.Name = "Column14"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(175, 23)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(180, 20)
        Me.TextBox4.TabIndex = 2
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(6, 20)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(108, 23)
        Me.Button10.TabIndex = 1
        Me.Button10.Text = "Search Payments"
        Me.Button10.UseVisualStyleBackColor = true
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(6, 87)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(108, 23)
        Me.Button17.TabIndex = 0
        Me.Button17.Text = "View Payments"
        Me.Button17.UseVisualStyleBackColor = true
        '
        'Supplier
        '
        Me.Supplier.Controls.Add(Me.Panel2)
        Me.Supplier.Controls.Add(Me.ComboBox5)
        Me.Supplier.Controls.Add(Me.Button3)
        Me.Supplier.Controls.Add(Me.ComboBox4)
        Me.Supplier.Controls.Add(Me.DataGridView3)
        Me.Supplier.Controls.Add(Me.Button6)
        Me.Supplier.Controls.Add(Me.TextBox2)
        Me.Supplier.Location = New System.Drawing.Point(4, 22)
        Me.Supplier.Name = "Supplier"
        Me.Supplier.Padding = New System.Windows.Forms.Padding(3)
        Me.Supplier.Size = New System.Drawing.Size(1240, 622)
        Me.Supplier.TabIndex = 13
        Me.Supplier.Text = "Supplier"
        Me.Supplier.UseVisualStyleBackColor = true
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Button5)
        Me.Panel2.Controls.Add(Me.Button7)
        Me.Panel2.Controls.Add(Me.Button8)
        Me.Panel2.Controls.Add(Me.Button9)
        Me.Panel2.Location = New System.Drawing.Point(687, 39)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(131, 415)
        Me.Panel2.TabIndex = 65
        '
        'Button5
        '
        Me.Button5.Image = Global.MenuForms.My.Resources.Resources.bin_red_full_icon
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button5.Location = New System.Drawing.Point(7, 306)
        Me.Button5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(121, 88)
        Me.Button5.TabIndex = 31
        Me.Button5.Text = "Remove"
        Me.Button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button5.UseVisualStyleBackColor = true
        '
        'Button7
        '
        Me.Button7.Image = Global.MenuForms.My.Resources.Resources.Save_icon
        Me.Button7.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button7.Location = New System.Drawing.Point(7, 207)
        Me.Button7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(121, 91)
        Me.Button7.TabIndex = 30
        Me.Button7.Text = "Save"
        Me.Button7.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button7.UseVisualStyleBackColor = true
        '
        'Button8
        '
        Me.Button8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Button8.Image = Global.MenuForms.My.Resources.Resources.Pencil_icon
        Me.Button8.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button8.Location = New System.Drawing.Point(7, 112)
        Me.Button8.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(121, 87)
        Me.Button8.TabIndex = 29
        Me.Button8.Text = "Update"
        Me.Button8.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button8.UseCompatibleTextRendering = true
        Me.Button8.UseVisualStyleBackColor = true
        '
        'Button9
        '
        Me.Button9.Image = Global.MenuForms.My.Resources.Resources.add_icon
        Me.Button9.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button9.Location = New System.Drawing.Point(7, 15)
        Me.Button9.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(121, 89)
        Me.Button9.TabIndex = 28
        Me.Button9.Text = "Add New Supplier"
        Me.Button9.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button9.UseVisualStyleBackColor = true
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = true
        Me.ComboBox5.Location = New System.Drawing.Point(165, 102)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox5.TabIndex = 64
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(6, 100)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(108, 23)
        Me.Button3.TabIndex = 63
        Me.Button3.Text = "View Supplier"
        Me.Button3.UseVisualStyleBackColor = true
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = true
        Me.ComboBox4.Location = New System.Drawing.Point(277, 39)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox4.TabIndex = 62
        '
        'DataGridView3
        '
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column15, Me.Column16, Me.Column17, Me.Column18, Me.Column19, Me.Column20})
        Me.DataGridView3.Location = New System.Drawing.Point(6, 161)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.Size = New System.Drawing.Size(644, 306)
        Me.DataGridView3.TabIndex = 61
        '
        'Column15
        '
        Me.Column15.HeaderText = "Supplier ID"
        Me.Column15.Name = "Column15"
        '
        'Column16
        '
        Me.Column16.HeaderText = "Supplier Name"
        Me.Column16.Name = "Column16"
        '
        'Column17
        '
        Me.Column17.HeaderText = "Contact Number"
        Me.Column17.Name = "Column17"
        '
        'Column18
        '
        Me.Column18.HeaderText = "Supplier Email"
        Me.Column18.Name = "Column18"
        '
        'Column19
        '
        Me.Column19.HeaderText = "Supplier Contact Person"
        Me.Column19.Name = "Column19"
        '
        'Column20
        '
        Me.Column20.HeaderText = "Address"
        Me.Column20.Name = "Column20"
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(6, 35)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 29)
        Me.Button6.TabIndex = 58
        Me.Button6.Text = "Search"
        Me.Button6.UseVisualStyleBackColor = true
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(118, 40)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 57
        '
        'GenManager
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1279, 701)
        Me.Controls.Add(Me.Product)
        Me.Name = "GenManager"
        Me.Text = "General Manager"
        Me.PurchaseOrder.ResumeLayout(false)
        Me.PurchaseOrder.PerformLayout
        CType(Me.DataGridView1,System.ComponentModel.ISupportInitialize).EndInit
        Me.Employee.ResumeLayout(false)
        Me.Employee.PerformLayout
        Me.Product.ResumeLayout(false)
        Me.Products.ResumeLayout(false)
        Me.Products.PerformLayout
        Me.Panel3.ResumeLayout(false)
        CType(Me.DataGridView5,System.ComponentModel.ISupportInitialize).EndInit
        Me.Customer.ResumeLayout(false)
        Me.Customer.PerformLayout
        Me.Panel1.ResumeLayout(false)
        CType(Me.DataGridView2,System.ComponentModel.ISupportInitialize).EndInit
        Me.Payment.ResumeLayout(false)
        Me.Payment.PerformLayout
        CType(Me.DataGridView4,System.ComponentModel.ISupportInitialize).EndInit
        Me.Supplier.ResumeLayout(false)
        Me.Supplier.PerformLayout
        Me.Panel2.ResumeLayout(false)
        CType(Me.DataGridView3,System.ComponentModel.ISupportInitialize).EndInit
        Me.ResumeLayout(false)

End Sub
    Friend WithEvents PurchaseOrder As TabPage
    Friend WithEvents TextBox58 As TextBox
    Friend WithEvents Label53 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Button19 As Button
    Friend WithEvents Employee As TabPage
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents TextBox38 As TextBox
    Friend WithEvents TextBox39 As TextBox
    Friend WithEvents TextBox40 As TextBox
    Friend WithEvents TextBox41 As TextBox
    Friend WithEvents TextBox42 As TextBox
    Friend WithEvents TextBox43 As TextBox
    Friend WithEvents TextBox44 As TextBox
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Product As TabControl
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Product_Code As DataGridViewTextBoxColumn
    Friend WithEvents Cost_Price As DataGridViewTextBoxColumn
    Friend WithEvents Purchase_Quantity As DataGridViewTextBoxColumn
    Friend WithEvents Subtotal As DataGridViewTextBoxColumn
    Friend WithEvents Total_Cost As DataGridViewTextBoxColumn
    Friend WithEvents Customer As TabPage
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnRemove As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents btnAddNewProduct As Button
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents Button1 As Button
    Friend WithEvents Supplier As TabPage
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button5 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents ComboBox5 As ComboBox
    Friend WithEvents Button3 As Button
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents DataGridView3 As DataGridView
    Friend WithEvents Column15 As DataGridViewTextBoxColumn
    Friend WithEvents Column16 As DataGridViewTextBoxColumn
    Friend WithEvents Column17 As DataGridViewTextBoxColumn
    Friend WithEvents Column18 As DataGridViewTextBoxColumn
    Friend WithEvents Column19 As DataGridViewTextBoxColumn
    Friend WithEvents Column20 As DataGridViewTextBoxColumn
    Friend WithEvents Button6 As Button
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Payment As TabPage
    Friend WithEvents ComboBox6 As ComboBox
    Friend WithEvents ComboBox7 As ComboBox
    Friend WithEvents DataGridView4 As DataGridView
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents Column10 As DataGridViewTextBoxColumn
    Friend WithEvents Column11 As DataGridViewTextBoxColumn
    Friend WithEvents Column12 As DataGridViewTextBoxColumn
    Friend WithEvents Column13 As DataGridViewTextBoxColumn
    Friend WithEvents Column14 As DataGridViewTextBoxColumn
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Button10 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Products As TabPage
    Friend WithEvents Panel3 As Panel
    Friend WithEvents btrnDisableProduct As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents cbSearchParam As ComboBox
    Friend WithEvents DataGridView5 As DataGridView
    Friend WithEvents ProductCode As DataGridViewTextBoxColumn
    Friend WithEvents ProductDescript As DataGridViewTextBoxColumn
    Friend WithEvents SellingPrice As DataGridViewTextBoxColumn
    Friend WithEvents OnHand As DataGridViewTextBoxColumn
    Friend WithEvents Vat As DataGridViewCheckBoxColumn
    Friend WithEvents Active As DataGridViewCheckBoxColumn
    Friend WithEvents PONum As DataGridViewTextBoxColumn
    Friend WithEvents PoDate As DataGridViewTextBoxColumn
    Friend WithEvents ReturnId As DataGridViewTextBoxColumn
    Friend WithEvents LastReturnDate As DataGridViewTextBoxColumn
    Friend WithEvents tbcSupplier As DataGridViewTextBoxColumn
    Friend WithEvents TextBox21 As TextBox
    Friend WithEvents Button21 As Button
End Class
