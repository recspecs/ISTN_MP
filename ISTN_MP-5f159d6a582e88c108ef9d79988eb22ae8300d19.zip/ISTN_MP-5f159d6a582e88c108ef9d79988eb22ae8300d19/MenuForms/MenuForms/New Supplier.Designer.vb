﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NewSupplier
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBox73 = New System.Windows.Forms.TextBox()
        Me.TextBox74 = New System.Windows.Forms.TextBox()
        Me.TextBox75 = New System.Windows.Forms.TextBox()
        Me.TextBox76 = New System.Windows.Forms.TextBox()
        Me.TextBox77 = New System.Windows.Forms.TextBox()
        Me.TextBox68 = New System.Windows.Forms.TextBox()
        Me.TextBox69 = New System.Windows.Forms.TextBox()
        Me.TextBox70 = New System.Windows.Forms.TextBox()
        Me.TextBox71 = New System.Windows.Forms.TextBox()
        Me.TextBox72 = New System.Windows.Forms.TextBox()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.SuspendLayout
        '
        'TextBox73
        '
        Me.TextBox73.Location = New System.Drawing.Point(285, 201)
        Me.TextBox73.Margin = New System.Windows.Forms.Padding(10)
        Me.TextBox73.Name = "TextBox73"
        Me.TextBox73.Size = New System.Drawing.Size(216, 20)
        Me.TextBox73.TabIndex = 65
        '
        'TextBox74
        '
        Me.TextBox74.Location = New System.Drawing.Point(285, 161)
        Me.TextBox74.Margin = New System.Windows.Forms.Padding(10)
        Me.TextBox74.Name = "TextBox74"
        Me.TextBox74.Size = New System.Drawing.Size(216, 20)
        Me.TextBox74.TabIndex = 64
        '
        'TextBox75
        '
        Me.TextBox75.Location = New System.Drawing.Point(285, 121)
        Me.TextBox75.Margin = New System.Windows.Forms.Padding(10)
        Me.TextBox75.Name = "TextBox75"
        Me.TextBox75.Size = New System.Drawing.Size(216, 20)
        Me.TextBox75.TabIndex = 63
        '
        'TextBox76
        '
        Me.TextBox76.Location = New System.Drawing.Point(285, 81)
        Me.TextBox76.Margin = New System.Windows.Forms.Padding(10)
        Me.TextBox76.Name = "TextBox76"
        Me.TextBox76.Size = New System.Drawing.Size(216, 20)
        Me.TextBox76.TabIndex = 62
        '
        'TextBox77
        '
        Me.TextBox77.Location = New System.Drawing.Point(285, 41)
        Me.TextBox77.Margin = New System.Windows.Forms.Padding(10)
        Me.TextBox77.Name = "TextBox77"
        Me.TextBox77.Size = New System.Drawing.Size(216, 20)
        Me.TextBox77.TabIndex = 61
        '
        'TextBox68
        '
        Me.TextBox68.Location = New System.Drawing.Point(285, 401)
        Me.TextBox68.Margin = New System.Windows.Forms.Padding(10)
        Me.TextBox68.Name = "TextBox68"
        Me.TextBox68.Size = New System.Drawing.Size(216, 20)
        Me.TextBox68.TabIndex = 10
        '
        'TextBox69
        '
        Me.TextBox69.Location = New System.Drawing.Point(285, 361)
        Me.TextBox69.Margin = New System.Windows.Forms.Padding(10)
        Me.TextBox69.Name = "TextBox69"
        Me.TextBox69.Size = New System.Drawing.Size(216, 20)
        Me.TextBox69.TabIndex = 9
        '
        'TextBox70
        '
        Me.TextBox70.Location = New System.Drawing.Point(285, 281)
        Me.TextBox70.Margin = New System.Windows.Forms.Padding(10)
        Me.TextBox70.Name = "TextBox70"
        Me.TextBox70.Size = New System.Drawing.Size(216, 20)
        Me.TextBox70.TabIndex = 8
        '
        'TextBox71
        '
        Me.TextBox71.Location = New System.Drawing.Point(285, 321)
        Me.TextBox71.Margin = New System.Windows.Forms.Padding(10)
        Me.TextBox71.Name = "TextBox71"
        Me.TextBox71.Size = New System.Drawing.Size(216, 20)
        Me.TextBox71.TabIndex = 7
        '
        'TextBox72
        '
        Me.TextBox72.Location = New System.Drawing.Point(285, 241)
        Me.TextBox72.Margin = New System.Windows.Forms.Padding(10)
        Me.TextBox72.Name = "TextBox72"
        Me.TextBox72.Size = New System.Drawing.Size(216, 20)
        Me.TextBox72.TabIndex = 6
        '
        'Label68
        '
        Me.Label68.AutoSize = true
        Me.Label68.Location = New System.Drawing.Point(109, 401)
        Me.Label68.Margin = New System.Windows.Forms.Padding(10)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(92, 13)
        Me.Label68.TabIndex = 4
        Me.Label68.Text = "Supp Postal Code"
        '
        'Label69
        '
        Me.Label69.AutoSize = true
        Me.Label69.Location = New System.Drawing.Point(109, 361)
        Me.Label69.Margin = New System.Windows.Forms.Padding(10)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(52, 13)
        Me.Label69.TabIndex = 3
        Me.Label69.Text = "Supp City"
        '
        'Label70
        '
        Me.Label70.AutoSize = true
        Me.Label70.Location = New System.Drawing.Point(109, 321)
        Me.Label70.Margin = New System.Windows.Forms.Padding(10)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(69, 13)
        Me.Label70.TabIndex = 2
        Me.Label70.Text = "Supp Suburb"
        '
        'Label71
        '
        Me.Label71.AutoSize = true
        Me.Label71.Location = New System.Drawing.Point(109, 281)
        Me.Label71.Margin = New System.Windows.Forms.Padding(10)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(82, 13)
        Me.Label71.TabIndex = 1
        Me.Label71.Text = "Supp Address 2"
        '
        'Label72
        '
        Me.Label72.AutoSize = true
        Me.Label72.Location = New System.Drawing.Point(109, 241)
        Me.Label72.Margin = New System.Windows.Forms.Padding(10)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(82, 13)
        Me.Label72.TabIndex = 0
        Me.Label72.Text = "Supp Address 1"
        '
        'Label73
        '
        Me.Label73.AutoSize = true
        Me.Label73.Location = New System.Drawing.Point(109, 81)
        Me.Label73.Margin = New System.Windows.Forms.Padding(10)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(76, 13)
        Me.Label73.TabIndex = 56
        Me.Label73.Text = "Supplier Name"
        '
        'Label74
        '
        Me.Label74.AutoSize = true
        Me.Label74.Location = New System.Drawing.Point(109, 41)
        Me.Label74.Margin = New System.Windows.Forms.Padding(10)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(59, 13)
        Me.Label74.TabIndex = 57
        Me.Label74.Text = "Supplier ID"
        '
        'Label75
        '
        Me.Label75.AutoSize = true
        Me.Label75.Location = New System.Drawing.Point(109, 201)
        Me.Label75.Margin = New System.Windows.Forms.Padding(10)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(108, 13)
        Me.Label75.TabIndex = 60
        Me.Label75.Text = "Supp Contact Person"
        '
        'Label76
        '
        Me.Label76.AutoSize = true
        Me.Label76.Location = New System.Drawing.Point(109, 161)
        Me.Label76.Margin = New System.Windows.Forms.Padding(10)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(59, 13)
        Me.Label76.TabIndex = 59
        Me.Label76.Text = "Supp email"
        '
        'Label77
        '
        Me.Label77.AutoSize = true
        Me.Label77.Location = New System.Drawing.Point(109, 121)
        Me.Label77.Margin = New System.Windows.Forms.Padding(10)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(84, 13)
        Me.Label77.TabIndex = 58
        Me.Label77.Text = "Contact Number"
        '
        'btnCancel
        '
        Me.btnCancel.Image = Global.MenuForms.My.Resources.Resources.delete_icon__1_
        Me.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.Location = New System.Drawing.Point(354, 457)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Padding = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.btnCancel.Size = New System.Drawing.Size(92, 40)
        Me.btnCancel.TabIndex = 67
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnCancel.UseVisualStyleBackColor = true
        '
        'btnAdd
        '
        Me.btnAdd.Image = Global.MenuForms.My.Resources.Resources.Action_ok_icon
        Me.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAdd.Location = New System.Drawing.Point(149, 457)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Padding = New System.Windows.Forms.Padding(10, 0, 10, 0)
        Me.btnAdd.Size = New System.Drawing.Size(92, 40)
        Me.btnAdd.TabIndex = 66
        Me.btnAdd.Text = "Add"
        Me.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnAdd.UseVisualStyleBackColor = true
        '
        'NewSupplier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(600, 536)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.Label69)
        Me.Controls.Add(Me.Label68)
        Me.Controls.Add(Me.TextBox68)
        Me.Controls.Add(Me.TextBox73)
        Me.Controls.Add(Me.TextBox69)
        Me.Controls.Add(Me.TextBox74)
        Me.Controls.Add(Me.TextBox70)
        Me.Controls.Add(Me.TextBox75)
        Me.Controls.Add(Me.TextBox71)
        Me.Controls.Add(Me.TextBox76)
        Me.Controls.Add(Me.Label70)
        Me.Controls.Add(Me.TextBox72)
        Me.Controls.Add(Me.TextBox77)
        Me.Controls.Add(Me.Label71)
        Me.Controls.Add(Me.Label73)
        Me.Controls.Add(Me.Label74)
        Me.Controls.Add(Me.Label75)
        Me.Controls.Add(Me.Label72)
        Me.Controls.Add(Me.Label76)
        Me.Controls.Add(Me.Label77)
        Me.Name = "NewSupplier"
        Me.Text = "New Supplier"
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub

    Friend WithEvents TextBox73 As TextBox
    Friend WithEvents TextBox74 As TextBox
    Friend WithEvents TextBox75 As TextBox
    Friend WithEvents TextBox76 As TextBox
    Friend WithEvents TextBox77 As TextBox
    Friend WithEvents TextBox68 As TextBox
    Friend WithEvents TextBox69 As TextBox
    Friend WithEvents TextBox70 As TextBox
    Friend WithEvents TextBox71 As TextBox
    Friend WithEvents TextBox72 As TextBox
    Friend WithEvents Label68 As Label
    Friend WithEvents Label69 As Label
    Friend WithEvents Label70 As Label
    Friend WithEvents Label71 As Label
    Friend WithEvents Label72 As Label
    Friend WithEvents Label73 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents Label76 As Label
    Friend WithEvents Label77 As Label
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnAdd As Button
End Class
