﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EmployeeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PurchasesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SuppliersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CaptureOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CapturePaymentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddProductToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddStockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewCustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchCustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchCustomersToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.SalesRep_RadioButton = New System.Windows.Forms.RadioButton()
        Me.Manager_RadioButton = New System.Windows.Forms.RadioButton()
        Me.LoginBtn = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.WarehouseMngRadioBtn = New System.Windows.Forms.RadioButton()
        Me.SalesRepRadioButton = New System.Windows.Forms.RadioButton()
        Me.GmRadioBtn = New System.Windows.Forms.RadioButton()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(94, 20)
        Me.ToolStripMenuItem1.Text = "Capture Order"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(111, 20)
        Me.ToolStripMenuItem2.Text = "Capture Payment"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(85, 20)
        Me.ToolStripMenuItem3.Text = "Product Info"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(141, 22)
        Me.ToolStripMenuItem4.Text = "Add Product"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(141, 22)
        Me.ToolStripMenuItem5.Text = "Add Stock"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(99, 20)
        Me.ToolStripMenuItem6.Text = "View Customer"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(169, 22)
        Me.ToolStripMenuItem7.Text = "ADD Customer"
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(169, 22)
        Me.ToolStripMenuItem8.Text = "Search Customers"
        '
        'EmployeeToolStripMenuItem
        '
        Me.EmployeeToolStripMenuItem.Name = "EmployeeToolStripMenuItem"
        Me.EmployeeToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.EmployeeToolStripMenuItem.Text = "Employee"
        '
        'PurchasesToolStripMenuItem
        '
        Me.PurchasesToolStripMenuItem.Name = "PurchasesToolStripMenuItem"
        Me.PurchasesToolStripMenuItem.Size = New System.Drawing.Size(72, 20)
        Me.PurchasesToolStripMenuItem.Text = "Purchases"
        '
        'SuppliersToolStripMenuItem
        '
        Me.SuppliersToolStripMenuItem.Name = "SuppliersToolStripMenuItem"
        Me.SuppliersToolStripMenuItem.Size = New System.Drawing.Size(67, 20)
        Me.SuppliersToolStripMenuItem.Text = "Suppliers"
        '
        'SalesToolStripMenuItem
        '
        Me.SalesToolStripMenuItem.Name = "SalesToolStripMenuItem"
        Me.SalesToolStripMenuItem.Size = New System.Drawing.Size(45, 20)
        Me.SalesToolStripMenuItem.Text = "Sales"
        '
        'CaptureOrderToolStripMenuItem
        '
        Me.CaptureOrderToolStripMenuItem.Name = "CaptureOrderToolStripMenuItem"
        Me.CaptureOrderToolStripMenuItem.Size = New System.Drawing.Size(94, 20)
        Me.CaptureOrderToolStripMenuItem.Text = "Capture Order"
        '
        'CapturePaymentToolStripMenuItem
        '
        Me.CapturePaymentToolStripMenuItem.Name = "CapturePaymentToolStripMenuItem"
        Me.CapturePaymentToolStripMenuItem.Size = New System.Drawing.Size(111, 20)
        Me.CapturePaymentToolStripMenuItem.Text = "Capture Payment"
        '
        'ProductInfoToolStripMenuItem
        '
        Me.ProductInfoToolStripMenuItem.Name = "ProductInfoToolStripMenuItem"
        Me.ProductInfoToolStripMenuItem.Size = New System.Drawing.Size(85, 20)
        Me.ProductInfoToolStripMenuItem.Text = "Product Info"
        '
        'AddProductToolStripMenuItem
        '
        Me.AddProductToolStripMenuItem.Name = "AddProductToolStripMenuItem"
        Me.AddProductToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.AddProductToolStripMenuItem.Text = "Add Product"
        '
        'AddStockToolStripMenuItem
        '
        Me.AddStockToolStripMenuItem.Name = "AddStockToolStripMenuItem"
        Me.AddStockToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.AddStockToolStripMenuItem.Text = "Add Stock"
        '
        'ViewCustomerToolStripMenuItem
        '
        Me.ViewCustomerToolStripMenuItem.Name = "ViewCustomerToolStripMenuItem"
        Me.ViewCustomerToolStripMenuItem.Size = New System.Drawing.Size(99, 20)
        Me.ViewCustomerToolStripMenuItem.Text = "View Customer"
        '
        'SearchCustomersToolStripMenuItem
        '
        Me.SearchCustomersToolStripMenuItem.Name = "SearchCustomersToolStripMenuItem"
        Me.SearchCustomersToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.SearchCustomersToolStripMenuItem.Text = "ADD Customer"
        '
        'SearchCustomersToolStripMenuItem1
        '
        Me.SearchCustomersToolStripMenuItem1.Name = "SearchCustomersToolStripMenuItem1"
        Me.SearchCustomersToolStripMenuItem1.Size = New System.Drawing.Size(169, 22)
        Me.SearchCustomersToolStripMenuItem1.Text = "Search Customers"
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(7, 29)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(69, 17)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Customer"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'SalesRep_RadioButton
        '
        Me.SalesRep_RadioButton.AutoSize = True
        Me.SalesRep_RadioButton.Location = New System.Drawing.Point(7, 53)
        Me.SalesRep_RadioButton.Name = "SalesRep_RadioButton"
        Me.SalesRep_RadioButton.Size = New System.Drawing.Size(74, 17)
        Me.SalesRep_RadioButton.TabIndex = 1
        Me.SalesRep_RadioButton.TabStop = True
        Me.SalesRep_RadioButton.Text = "Sales Rep"
        Me.SalesRep_RadioButton.UseVisualStyleBackColor = True
        '
        'Manager_RadioButton
        '
        Me.Manager_RadioButton.AutoSize = True
        Me.Manager_RadioButton.Location = New System.Drawing.Point(7, 77)
        Me.Manager_RadioButton.Name = "Manager_RadioButton"
        Me.Manager_RadioButton.Size = New System.Drawing.Size(67, 17)
        Me.Manager_RadioButton.TabIndex = 2
        Me.Manager_RadioButton.TabStop = True
        Me.Manager_RadioButton.Text = "Manager"
        Me.Manager_RadioButton.UseVisualStyleBackColor = True
        '
        'LoginBtn
        '
        Me.LoginBtn.Location = New System.Drawing.Point(198, 249)
        Me.LoginBtn.Name = "LoginBtn"
        Me.LoginBtn.Size = New System.Drawing.Size(75, 23)
        Me.LoginBtn.TabIndex = 18
        Me.LoginBtn.Text = "Login"
        Me.LoginBtn.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(102, 194)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 17
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(102, 165)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 16
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(41, 194)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Password"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 168)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Username"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.GmRadioBtn)
        Me.GroupBox1.Controls.Add(Me.WarehouseMngRadioBtn)
        Me.GroupBox1.Controls.Add(Me.SalesRepRadioButton)
        Me.GroupBox1.Location = New System.Drawing.Point(28, 29)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(245, 130)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Login options"
        '
        'WarehouseMngRadioBtn
        '
        Me.WarehouseMngRadioBtn.AutoSize = True
        Me.WarehouseMngRadioBtn.Location = New System.Drawing.Point(7, 77)
        Me.WarehouseMngRadioBtn.Name = "WarehouseMngRadioBtn"
        Me.WarehouseMngRadioBtn.Size = New System.Drawing.Size(125, 17)
        Me.WarehouseMngRadioBtn.TabIndex = 2
        Me.WarehouseMngRadioBtn.TabStop = True
        Me.WarehouseMngRadioBtn.Text = "Warehouse Manager"
        Me.WarehouseMngRadioBtn.UseVisualStyleBackColor = True
        '
        'SalesRepRadioButton
        '
        Me.SalesRepRadioButton.AutoSize = True
        Me.SalesRepRadioButton.Location = New System.Drawing.Point(7, 53)
        Me.SalesRepRadioButton.Name = "SalesRepRadioButton"
        Me.SalesRepRadioButton.Size = New System.Drawing.Size(74, 17)
        Me.SalesRepRadioButton.TabIndex = 1
        Me.SalesRepRadioButton.TabStop = True
        Me.SalesRepRadioButton.Text = "Sales Rep"
        Me.SalesRepRadioButton.UseVisualStyleBackColor = True
        '
        'GmRadioBtn
        '
        Me.GmRadioBtn.AutoSize = True
        Me.GmRadioBtn.Location = New System.Drawing.Point(7, 101)
        Me.GmRadioBtn.Name = "GmRadioBtn"
        Me.GmRadioBtn.Size = New System.Drawing.Size(107, 17)
        Me.GmRadioBtn.TabIndex = 3
        Me.GmRadioBtn.TabStop = True
        Me.GmRadioBtn.Text = "General Manager"
        Me.GmRadioBtn.UseVisualStyleBackColor = True
        '
        'Login
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(436, 326)
        Me.Controls.Add(Me.LoginBtn)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Login"
        Me.Text = "Login"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As ToolStripMenuItem
    Friend WithEvents EmployeeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PurchasesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SuppliersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CaptureOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CapturePaymentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProductInfoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddProductToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddStockToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewCustomerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchCustomersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchCustomersToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents SalesRep_RadioButton As RadioButton
    Friend WithEvents Manager_RadioButton As RadioButton
    Friend WithEvents LoginBtn As Button
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents WarehouseMngRadioBtn As RadioButton
    Friend WithEvents SalesRepRadioButton As RadioButton
    Friend WithEvents GmRadioBtn As RadioButton
End Class
