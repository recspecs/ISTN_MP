﻿Public Class Add_New_Customer
    Private Sub Add_New_Customer_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class