﻿Public Class GenManager
    Private Sub Label58_Click(sender As Object, e As EventArgs) Handles Label58.Click

    End Sub
End Class