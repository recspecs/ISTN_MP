﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NewProduct
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.radioYes = New System.Windows.Forms.RadioButton()
        Me.TextBox51 = New System.Windows.Forms.TextBox()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.tbPrice = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblOnHand = New System.Windows.Forms.Label()
        Me.lblCategory = New System.Windows.Forms.Label()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.radioNo = New System.Windows.Forms.RadioButton()
        Me.cbUnit = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lboxCategories = New System.Windows.Forms.ListBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.lblSupplier = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.SuspendLayout
        '
        'radioYes
        '
        Me.radioYes.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.radioYes.AutoSize = true
        Me.radioYes.Checked = true
        Me.radioYes.Location = New System.Drawing.Point(193, 184)
        Me.radioYes.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.radioYes.Name = "radioYes"
        Me.radioYes.Size = New System.Drawing.Size(45, 21)
        Me.radioYes.TabIndex = 1
        Me.radioYes.TabStop = true
        Me.radioYes.Text = "Yes"
        Me.radioYes.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.radioYes.UseVisualStyleBackColor = true
        '
        'TextBox51
        '
        Me.TextBox51.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox51.Location = New System.Drawing.Point(193, 31)
        Me.TextBox51.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(186, 25)
        Me.TextBox51.TabIndex = 29
        '
        'TextBox47
        '
        Me.TextBox47.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox47.Location = New System.Drawing.Point(193, 135)
        Me.TextBox47.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(186, 25)
        Me.TextBox47.TabIndex = 38
        '
        'tbPrice
        '
        Me.tbPrice.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.tbPrice.Location = New System.Drawing.Point(193, 231)
        Me.tbPrice.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tbPrice.Name = "tbPrice"
        Me.tbPrice.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.tbPrice.Size = New System.Drawing.Size(186, 25)
        Me.tbPrice.TabIndex = 36
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label6.AutoSize = true
        Me.Label6.Location = New System.Drawing.Point(65, 235)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 17)
        Me.Label6.TabIndex = 33
        Me.Label6.Text = "Selling Price"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblOnHand
        '
        Me.lblOnHand.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblOnHand.AutoSize = true
        Me.lblOnHand.Location = New System.Drawing.Point(65, 139)
        Me.lblOnHand.Name = "lblOnHand"
        Me.lblOnHand.Size = New System.Drawing.Size(60, 17)
        Me.lblOnHand.TabIndex = 34
        Me.lblOnHand.Text = "On Hand"
        Me.lblOnHand.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblCategory
        '
        Me.lblCategory.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblCategory.AutoSize = true
        Me.lblCategory.Location = New System.Drawing.Point(441, 198)
        Me.lblCategory.Name = "lblCategory"
        Me.lblCategory.Size = New System.Drawing.Size(71, 17)
        Me.lblCategory.TabIndex = 32
        Me.lblCategory.Text = "Categories"
        Me.lblCategory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox48
        '
        Me.TextBox48.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox48.Location = New System.Drawing.Point(193, 81)
        Me.TextBox48.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(487, 25)
        Me.TextBox48.TabIndex = 37
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label3.AutoSize = true
        Me.Label3.Location = New System.Drawing.Point(65, 188)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 17)
        Me.Label3.TabIndex = 40
        Me.Label3.Text = "VAT"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.AutoSize = true
        Me.Label2.Location = New System.Drawing.Point(65, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 17)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "Product Name"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label1.AutoSize = true
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Label1.Location = New System.Drawing.Point(65, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 17)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Product Code"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'radioNo
        '
        Me.radioNo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.radioNo.AutoSize = true
        Me.radioNo.Location = New System.Drawing.Point(321, 186)
        Me.radioNo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.radioNo.Name = "radioNo"
        Me.radioNo.Size = New System.Drawing.Size(44, 21)
        Me.radioNo.TabIndex = 41
        Me.radioNo.Text = "No"
        Me.radioNo.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.radioNo.UseVisualStyleBackColor = true
        '
        'cbUnit
        '
        Me.cbUnit.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.cbUnit.FormattingEnabled = true
        Me.cbUnit.Items.AddRange(New Object() {"Liter(s)", "Piece(s) ", "Box(es)", "Roll(s)", "Pallet(s)", "Kg(s)", "Set(s)"})
        Me.cbUnit.Location = New System.Drawing.Point(193, 283)
        Me.cbUnit.Name = "cbUnit"
        Me.cbUnit.Size = New System.Drawing.Size(186, 25)
        Me.cbUnit.TabIndex = 42
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label5.AutoSize = true
        Me.Label5.Location = New System.Drawing.Point(65, 291)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(31, 17)
        Me.Label5.TabIndex = 43
        Me.Label5.Text = "Unit"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lboxCategories
        '
        Me.lboxCategories.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lboxCategories.FormattingEnabled = true
        Me.lboxCategories.ItemHeight = 17
        Me.lboxCategories.Items.AddRange(New Object() {"Food", "Softdrink"})
        Me.lboxCategories.Location = New System.Drawing.Point(518, 198)
        Me.lboxCategories.Name = "lboxCategories"
        Me.lboxCategories.Size = New System.Drawing.Size(162, 174)
        Me.lboxCategories.TabIndex = 44
        '
        'ComboBox1
        '
        Me.ComboBox1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.ComboBox1.FormattingEnabled = true
        Me.ComboBox1.Location = New System.Drawing.Point(193, 347)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(186, 25)
        Me.ComboBox1.TabIndex = 45
        '
        'lblSupplier
        '
        Me.lblSupplier.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblSupplier.AutoSize = true
        Me.lblSupplier.Location = New System.Drawing.Point(65, 355)
        Me.lblSupplier.Name = "lblSupplier"
        Me.lblSupplier.Size = New System.Drawing.Size(56, 17)
        Me.lblSupplier.TabIndex = 46
        Me.lblSupplier.Text = "Supplier"
        Me.lblSupplier.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnAdd
        '
        Me.btnAdd.Image = Global.MenuForms.My.Resources.Resources.Action_ok_icon
        Me.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAdd.Location = New System.Drawing.Point(420, 431)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Padding = New System.Windows.Forms.Padding(10, 0, 10, 0)
        Me.btnAdd.Size = New System.Drawing.Size(92, 40)
        Me.btnAdd.TabIndex = 47
        Me.btnAdd.Text = "Add"
        Me.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnAdd.UseVisualStyleBackColor = true
        '
        'btnCancel
        '
        Me.btnCancel.Image = Global.MenuForms.My.Resources.Resources.delete_icon__1_
        Me.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.Location = New System.Drawing.Point(588, 431)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Padding = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.btnCancel.Size = New System.Drawing.Size(92, 40)
        Me.btnCancel.TabIndex = 48
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnCancel.UseVisualStyleBackColor = true
        '
        'NewProduct
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7!, 17!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(740, 509)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.lblSupplier)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.lboxCategories)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.cbUnit)
        Me.Controls.Add(Me.radioNo)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.radioYes)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox51)
        Me.Controls.Add(Me.TextBox48)
        Me.Controls.Add(Me.TextBox47)
        Me.Controls.Add(Me.lblCategory)
        Me.Controls.Add(Me.tbPrice)
        Me.Controls.Add(Me.lblOnHand)
        Me.Controls.Add(Me.Label6)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "NewProduct"
        Me.Text = "Add New Product"
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub

    Friend WithEvents radioYes As RadioButton
    Friend WithEvents TextBox51 As TextBox
    Friend WithEvents TextBox47 As TextBox
    Friend WithEvents tbPrice As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents lblOnHand As Label
    Friend WithEvents lblCategory As Label
    Friend WithEvents TextBox48 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents radioNo As RadioButton
    Friend WithEvents cbUnit As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents lboxCategories As ListBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents lblSupplier As Label
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnCancel As Button
End Class
