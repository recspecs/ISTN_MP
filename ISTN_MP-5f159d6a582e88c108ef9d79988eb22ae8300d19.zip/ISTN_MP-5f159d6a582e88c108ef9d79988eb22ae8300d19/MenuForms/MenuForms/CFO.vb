﻿Public Class CFO
    Private Sub CaptureSalesOrderTab_Click(sender As Object, e As EventArgs) Handles CaptureSalesOrderTab.Click

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class