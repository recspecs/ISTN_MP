﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
		Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
		Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
		Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
		Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
		Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
		Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
		Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
		Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
		Me.EmployeeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.PurchasesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.SuppliersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.SalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.CaptureOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.CapturePaymentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.ProductInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.AddProductToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.AddStockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.ViewCustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.SearchCustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.SearchCustomersToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
		Me.RadioButton1 = New System.Windows.Forms.RadioButton()
		Me.SalesRep_RadioButton = New System.Windows.Forms.RadioButton()
		Me.Manager_RadioButton = New System.Windows.Forms.RadioButton()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.Button1 = New System.Windows.Forms.Button()
		Me.Button2 = New System.Windows.Forms.Button()
		Me.RecSpecDataset1 = New MenuForms.RecSpecDataset()
		Me.EmployeeTableAdapter1 = New MenuForms.RecSpecDatasetTableAdapters.EmployeeTableAdapter()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.TextBoxPassword = New System.Windows.Forms.MaskedTextBox()
		Me.TextBoxEmail = New System.Windows.Forms.TextBox()
		CType(Me.RecSpecDataset1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'ToolStripMenuItem1
		'
		Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
		Me.ToolStripMenuItem1.Size = New System.Drawing.Size(94, 20)
		Me.ToolStripMenuItem1.Text = "Capture Order"
		'
		'ToolStripMenuItem2
		'
		Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
		Me.ToolStripMenuItem2.Size = New System.Drawing.Size(111, 20)
		Me.ToolStripMenuItem2.Text = "Capture Payment"
		'
		'ToolStripMenuItem3
		'
		Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
		Me.ToolStripMenuItem3.Size = New System.Drawing.Size(85, 20)
		Me.ToolStripMenuItem3.Text = "Product Info"
		'
		'ToolStripMenuItem4
		'
		Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
		Me.ToolStripMenuItem4.Size = New System.Drawing.Size(141, 22)
		Me.ToolStripMenuItem4.Text = "Add Product"
		'
		'ToolStripMenuItem5
		'
		Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
		Me.ToolStripMenuItem5.Size = New System.Drawing.Size(141, 22)
		Me.ToolStripMenuItem5.Text = "Add Stock"
		'
		'ToolStripMenuItem6
		'
		Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
		Me.ToolStripMenuItem6.Size = New System.Drawing.Size(99, 20)
		Me.ToolStripMenuItem6.Text = "View Customer"
		'
		'ToolStripMenuItem7
		'
		Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
		Me.ToolStripMenuItem7.Size = New System.Drawing.Size(169, 22)
		Me.ToolStripMenuItem7.Text = "ADD Customer"
		'
		'ToolStripMenuItem8
		'
		Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
		Me.ToolStripMenuItem8.Size = New System.Drawing.Size(169, 22)
		Me.ToolStripMenuItem8.Text = "Search Customers"
		'
		'EmployeeToolStripMenuItem
		'
		Me.EmployeeToolStripMenuItem.Name = "EmployeeToolStripMenuItem"
		Me.EmployeeToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
		Me.EmployeeToolStripMenuItem.Text = "Employee"
		'
		'PurchasesToolStripMenuItem
		'
		Me.PurchasesToolStripMenuItem.Name = "PurchasesToolStripMenuItem"
		Me.PurchasesToolStripMenuItem.Size = New System.Drawing.Size(72, 20)
		Me.PurchasesToolStripMenuItem.Text = "Purchases"
		'
		'SuppliersToolStripMenuItem
		'
		Me.SuppliersToolStripMenuItem.Name = "SuppliersToolStripMenuItem"
		Me.SuppliersToolStripMenuItem.Size = New System.Drawing.Size(67, 20)
		Me.SuppliersToolStripMenuItem.Text = "Suppliers"
		'
		'SalesToolStripMenuItem
		'
		Me.SalesToolStripMenuItem.Name = "SalesToolStripMenuItem"
		Me.SalesToolStripMenuItem.Size = New System.Drawing.Size(45, 20)
		Me.SalesToolStripMenuItem.Text = "Sales"
		'
		'CaptureOrderToolStripMenuItem
		'
		Me.CaptureOrderToolStripMenuItem.Name = "CaptureOrderToolStripMenuItem"
		Me.CaptureOrderToolStripMenuItem.Size = New System.Drawing.Size(94, 20)
		Me.CaptureOrderToolStripMenuItem.Text = "Capture Order"
		'
		'CapturePaymentToolStripMenuItem
		'
		Me.CapturePaymentToolStripMenuItem.Name = "CapturePaymentToolStripMenuItem"
		Me.CapturePaymentToolStripMenuItem.Size = New System.Drawing.Size(111, 20)
		Me.CapturePaymentToolStripMenuItem.Text = "Capture Payment"
		'
		'ProductInfoToolStripMenuItem
		'
		Me.ProductInfoToolStripMenuItem.Name = "ProductInfoToolStripMenuItem"
		Me.ProductInfoToolStripMenuItem.Size = New System.Drawing.Size(85, 20)
		Me.ProductInfoToolStripMenuItem.Text = "Product Info"
		'
		'AddProductToolStripMenuItem
		'
		Me.AddProductToolStripMenuItem.Name = "AddProductToolStripMenuItem"
		Me.AddProductToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
		Me.AddProductToolStripMenuItem.Text = "Add Product"
		'
		'AddStockToolStripMenuItem
		'
		Me.AddStockToolStripMenuItem.Name = "AddStockToolStripMenuItem"
		Me.AddStockToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
		Me.AddStockToolStripMenuItem.Text = "Add Stock"
		'
		'ViewCustomerToolStripMenuItem
		'
		Me.ViewCustomerToolStripMenuItem.Name = "ViewCustomerToolStripMenuItem"
		Me.ViewCustomerToolStripMenuItem.Size = New System.Drawing.Size(99, 20)
		Me.ViewCustomerToolStripMenuItem.Text = "View Customer"
		'
		'SearchCustomersToolStripMenuItem
		'
		Me.SearchCustomersToolStripMenuItem.Name = "SearchCustomersToolStripMenuItem"
		Me.SearchCustomersToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
		Me.SearchCustomersToolStripMenuItem.Text = "ADD Customer"
		'
		'SearchCustomersToolStripMenuItem1
		'
		Me.SearchCustomersToolStripMenuItem1.Name = "SearchCustomersToolStripMenuItem1"
		Me.SearchCustomersToolStripMenuItem1.Size = New System.Drawing.Size(169, 22)
		Me.SearchCustomersToolStripMenuItem1.Text = "Search Customers"
		'
		'RadioButton1
		'
		Me.RadioButton1.AutoSize = True
		Me.RadioButton1.Location = New System.Drawing.Point(7, 29)
		Me.RadioButton1.Name = "RadioButton1"
		Me.RadioButton1.Size = New System.Drawing.Size(69, 17)
		Me.RadioButton1.TabIndex = 0
		Me.RadioButton1.TabStop = True
		Me.RadioButton1.Text = "Customer"
		Me.RadioButton1.UseVisualStyleBackColor = True
		'
		'SalesRep_RadioButton
		'
		Me.SalesRep_RadioButton.AutoSize = True
		Me.SalesRep_RadioButton.Location = New System.Drawing.Point(7, 53)
		Me.SalesRep_RadioButton.Name = "SalesRep_RadioButton"
		Me.SalesRep_RadioButton.Size = New System.Drawing.Size(74, 17)
		Me.SalesRep_RadioButton.TabIndex = 1
		Me.SalesRep_RadioButton.TabStop = True
		Me.SalesRep_RadioButton.Text = "Sales Rep"
		Me.SalesRep_RadioButton.UseVisualStyleBackColor = True
		'
		'Manager_RadioButton
		'
		Me.Manager_RadioButton.AutoSize = True
		Me.Manager_RadioButton.Location = New System.Drawing.Point(7, 77)
		Me.Manager_RadioButton.Name = "Manager_RadioButton"
		Me.Manager_RadioButton.Size = New System.Drawing.Size(67, 17)
		Me.Manager_RadioButton.TabIndex = 2
		Me.Manager_RadioButton.TabStop = True
		Me.Manager_RadioButton.Text = "Manager"
		Me.Manager_RadioButton.UseVisualStyleBackColor = True
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.BackColor = System.Drawing.Color.Transparent
		Me.Label1.Font = New System.Drawing.Font("Verdana", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.ForeColor = System.Drawing.Color.Black
		Me.Label1.Location = New System.Drawing.Point(369, 9)
		Me.Label1.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(231, 78)
		Me.Label1.TabIndex = 0
		Me.Label1.Text = "Login"
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Location = New System.Drawing.Point(158, 137)
		Me.Label2.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(164, 23)
		Me.Label2.TabIndex = 3
		Me.Label2.Text = "E-mail Address:"
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.Location = New System.Drawing.Point(213, 205)
		Me.Label3.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(109, 23)
		Me.Label3.TabIndex = 4
		Me.Label3.Text = "Password:"
		'
		'Button1
		'
		Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
		Me.Button1.Location = New System.Drawing.Point(347, 256)
		Me.Button1.Name = "Button1"
		Me.Button1.Size = New System.Drawing.Size(109, 36)
		Me.Button1.TabIndex = 5
		Me.Button1.Text = "LOGIN"
		Me.Button1.UseVisualStyleBackColor = False
		'
		'Button2
		'
		Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
		Me.Button2.Location = New System.Drawing.Point(526, 256)
		Me.Button2.Name = "Button2"
		Me.Button2.Size = New System.Drawing.Size(109, 36)
		Me.Button2.TabIndex = 6
		Me.Button2.Text = "CANCEL"
		Me.Button2.UseVisualStyleBackColor = False
		'
		'RecSpecDataset1
		'
		Me.RecSpecDataset1.DataSetName = "RecSpecDataset"
		Me.RecSpecDataset1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
		'
		'EmployeeTableAdapter1
		'
		Me.EmployeeTableAdapter1.ClearBeforeFill = True
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.BackColor = System.Drawing.Color.Transparent
		Me.Label4.Font = New System.Drawing.Font("Verdana", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.ForeColor = System.Drawing.Color.Black
		Me.Label4.Location = New System.Drawing.Point(117, 338)
		Me.Label4.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(788, 45)
		Me.Label4.TabIndex = 7
		Me.Label4.Text = "SVG SALES AND INVENTORY SYSTEM"
		'
		'Label5
		'
		Me.Label5.AutoSize = True
		Me.Label5.BackColor = System.Drawing.Color.Transparent
		Me.Label5.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label5.ForeColor = System.Drawing.Color.Black
		Me.Label5.Location = New System.Drawing.Point(321, 383)
		Me.Label5.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(376, 23)
		Me.Label5.TabIndex = 8
		Me.Label5.Text = "Designed by Recommended Specs"
		'
		'TextBoxPassword
		'
		Me.TextBoxPassword.ImeMode = System.Windows.Forms.ImeMode.Katakana
		Me.TextBoxPassword.Location = New System.Drawing.Point(347, 202)
		Me.TextBoxPassword.Name = "TextBoxPassword"
		Me.TextBoxPassword.Size = New System.Drawing.Size(288, 31)
		Me.TextBoxPassword.TabIndex = 9
		'
		'TextBoxEmail
		'
		Me.TextBoxEmail.Location = New System.Drawing.Point(347, 134)
		Me.TextBoxEmail.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
		Me.TextBoxEmail.Name = "TextBoxEmail"
		Me.TextBoxEmail.Size = New System.Drawing.Size(288, 31)
		Me.TextBoxEmail.TabIndex = 1
		'
		'Login
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 23.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.Color.Gray
		Me.ClientSize = New System.Drawing.Size(977, 448)
		Me.Controls.Add(Me.TextBoxPassword)
		Me.Controls.Add(Me.Label5)
		Me.Controls.Add(Me.Label4)
		Me.Controls.Add(Me.Button2)
		Me.Controls.Add(Me.Button1)
		Me.Controls.Add(Me.Label3)
		Me.Controls.Add(Me.Label2)
		Me.Controls.Add(Me.TextBoxEmail)
		Me.Controls.Add(Me.Label1)
		Me.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.ForeColor = System.Drawing.Color.Black
		Me.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
		Me.Name = "Login"
		Me.Text = "Login"
		CType(Me.RecSpecDataset1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As ToolStripMenuItem
    Friend WithEvents EmployeeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PurchasesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SuppliersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CaptureOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CapturePaymentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProductInfoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddProductToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddStockToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewCustomerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchCustomersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchCustomersToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents SalesRep_RadioButton As RadioButton
    Friend WithEvents Manager_RadioButton As RadioButton
    Friend WithEvents Label1 As Label
	Friend WithEvents Label2 As Label
	Friend WithEvents Label3 As Label
	Friend WithEvents Button1 As Button
	Friend WithEvents Button2 As Button
	Friend WithEvents RecSpecDataset1 As RecSpecDataset
	Friend WithEvents EmployeeTableAdapter1 As RecSpecDatasetTableAdapters.EmployeeTableAdapter
	Friend WithEvents Label4 As Label
	Friend WithEvents Label5 As Label
	Friend WithEvents TextBoxPassword As MaskedTextBox
	Friend WithEvents TextBoxEmail As TextBox
End Class
